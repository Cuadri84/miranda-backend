export interface IAuthUser {
  name: string;
  mail: string;
  pass: string;
}
