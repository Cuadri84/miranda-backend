export interface ILogin {
  name: string;
  mail: string;
  pass: string;
}
